# Toko Sembako — APK build-ready

Ini adalah proyek Flask + SQLite yang dibungkus Kivy/WebView untuk Android.
Jangan gunakan AppsGeyser ZIP untuk proyek ini karena AppsGeyser mengharapkan web statis dengan index.html.

Cara build yang disiapkan:
1. Masukkan isi folder proyek ini ke repository GitHub.
2. Buka tab Actions.
3. Jalankan workflow "Build Toko Sembako APK" (atau push ke main).
4. Setelah selesai, buka Artifacts dan unduh `toko-sembako-apk`.

Buildozer akan menyiapkan Android SDK/NDK dan menghasilkan APK.
