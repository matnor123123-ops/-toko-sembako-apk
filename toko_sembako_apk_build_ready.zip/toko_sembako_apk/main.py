__version__ = "1.0.0"
import threading, time
from app import app
from kivy.app import App
from kivy.clock import Clock
from kivy.uix.widget import Widget

def run_server():
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)

class Root(Widget):
    pass

class TokoSembakoApp(App):
    def build(self):
        from jnius import autoclass
        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        WebView = autoclass("android.webkit.WebView")
        WebSettings = autoclass("android.webkit.WebSettings")
        activity = PythonActivity.mActivity
        self.webview = WebView(activity)
        settings = self.webview.getSettings()
        settings.setJavaScriptEnabled(True)
        settings.setDomStorageEnabled(True)
        settings.setBuiltInZoomControls(False)
        self.webview.loadUrl("http://127.0.0.1:5000/")
        activity.setContentView(self.webview)
        return Root()

if __name__ == "__main__":
    threading.Thread(target=run_server, daemon=True).start()
    time.sleep(1)
    TokoSembakoApp().run()
