from datetime import datetime
from functools import wraps
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///sembako.db"
app.config["SECRET_KEY"] = "rahasia-toko-sembako-ganti-ini"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    role = db.Column(db.String(20), nullable=False)
    pin_hash = db.Column(db.String(255), nullable=False)


class Produk(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(100), nullable=False)
    kategori = db.Column(db.String(50), default="")
    satuan = db.Column(db.String(20), nullable=False)
    harga_modal = db.Column(db.Float, nullable=False)
    harga_jual = db.Column(db.Float, nullable=False)
    stok = db.Column(db.Float, default=0.0)
    stok_minimum = db.Column(db.Float, default=5.0)


class Supplier(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(100), nullable=False)
    kontak = db.Column(db.String(50), default="")


class StokMasuk(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    produk_id = db.Column(db.Integer, db.ForeignKey("produk.id"), nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey("supplier.id"), nullable=False)
    jumlah = db.Column(db.Float, nullable=False)
    tanggal = db.Column(db.DateTime, default=datetime.utcnow)
    produk = db.relationship("Produk", backref="stok_masuk")
    supplier = db.relationship("Supplier", backref="pasokan")


class Transaksi(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tanggal = db.Column(db.DateTime, default=datetime.utcnow)
    kasir = db.Column(db.String(50), nullable=False)
    total_belanja = db.Column(db.Float, nullable=False)
    diskon = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(20), default="Selesai")
    pelanggan_nama = db.Column(db.String(100), default="Umum")


class DetailTransaksi(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transaksi_id = db.Column(db.Integer, db.ForeignKey("transaksi.id"), nullable=False)
    produk_id = db.Column(db.Integer, db.ForeignKey("produk.id"), nullable=False)
    jumlah = db.Column(db.Float, nullable=False)
    harga_satuan = db.Column(db.Float, nullable=False)
    subtotal = db.Column(db.Float, nullable=False)
    transaksi = db.relationship("Transaksi", backref="detail")
    produk = db.relationship("Produk")


class Hutang(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pelanggan_nama = db.Column(db.String(100), nullable=False)
    total_hutang = db.Column(db.Float, nullable=False)
    sisa_hutang = db.Column(db.Float, nullable=False)
    tanggal = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Belum Lunas")


class CicilanHutang(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hutang_id = db.Column(db.Integer, db.ForeignKey("hutang.id"), nullable=False)
    jumlah_bayar = db.Column(db.Float, nullable=False)
    tanggal = db.Column(db.DateTime, default=datetime.utcnow)
    hutang = db.relationship("Hutang", backref="cicilan")


class RiwayatAktivitas(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(50), nullable=False)
    aktivitas = db.Column(db.Text, nullable=False)
    tanggal = db.Column(db.DateTime, default=datetime.utcnow)


class Pengeluaran(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    keterangan = db.Column(db.String(255), nullable=False)
    jumlah = db.Column(db.Float, nullable=False)
    tanggal = db.Column(db.DateTime, default=datetime.utcnow)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def owner_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "owner":
            flash("Akses ditolak! Khusus Owner.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated


def verify_owner_pin(pin):
    owner = User.query.filter_by(role="owner").first()
    return bool(owner and check_password_hash(owner.pin_hash, pin or ""))


@app.template_filter("rupiah")
def rupiah(value):
    try:
        return f"Rp {float(value):,.0f}".replace(",", ".")
    except (TypeError, ValueError):
        return "Rp 0"


@app.route("/")
def index():
    return redirect(url_for("dashboard") if "user" in session else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        pin = request.form.get("pin", "")
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.pin_hash, pin):
            session["user"] = user.username
            session["role"] = user.role
            flash("Berhasil masuk!", "success")
            return redirect(url_for("dashboard"))
        flash("Username atau PIN salah!", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    stok_tipis = Produk.query.filter(Produk.stok <= Produk.stok_minimum).order_by(Produk.nama).all()
    today = datetime.utcnow().date()
    transaksi_hari_ini = Transaksi.query.filter(
        Transaksi.status == "Selesai",
        db.func.date(Transaksi.tanggal) == today
    ).all()
    omzet_hari_ini = sum(t.total_belanja for t in transaksi_hari_ini)
    return render_template(
        "dashboard.html",
        stok_tipis=stok_tipis,
        jumlah_produk=Produk.query.count(),
        omzet_hari_ini=omzet_hari_ini,
        jumlah_transaksi=len(transaksi_hari_ini),
    )


@app.route("/kasir", methods=["GET", "POST"])
@login_required
def kasir():
    produks = Produk.query.order_by(Produk.nama).all()
    if request.method == "POST":
        pelanggan = request.form.get("pelanggan", "Umum").strip() or "Umum"
        metode = request.form.get("metode_pembayaran", "tunai")
        item_ids = request.form.getlist("produk_id[]")
        jumlahs = request.form.getlist("jumlah[]")
        total = 0.0
        items = []

        for p_id, jml in zip(item_ids, jumlahs):
            try:
                qty = float(jml)
            except (TypeError, ValueError):
                qty = 0
            if qty <= 0:
                continue
            produk = db.session.get(Produk, int(p_id))
            if not produk:
                flash("Produk tidak ditemukan.", "danger")
                return redirect(url_for("kasir"))
            if produk.stok < qty:
                flash(f"Stok {produk.nama} tidak mencukupi!", "danger")
                return redirect(url_for("kasir"))
            subtotal = produk.harga_jual * qty
            total += subtotal
            items.append((produk, qty, subtotal))

        if not items:
            flash("Keranjang kosong!", "warning")
            return redirect(url_for("kasir"))

        transaksi = Transaksi(
            kasir=session["user"],
            total_belanja=total,
            pelanggan_nama=pelanggan,
        )
        db.session.add(transaksi)
        db.session.flush()

        for produk, qty, subtotal in items:
            db.session.add(DetailTransaksi(
                transaksi_id=transaksi.id,
                produk_id=produk.id,
                jumlah=qty,
                harga_satuan=produk.harga_jual,
                subtotal=subtotal,
            ))
            produk.stok -= qty

        if metode == "hutang":
            db.session.add(Hutang(
                pelanggan_nama=pelanggan,
                total_hutang=total,
                sisa_hutang=total,
            ))

        db.session.add(RiwayatAktivitas(
            user=session["user"],
            aktivitas=f"Penjualan #{transaksi.id} sebesar {rupiah(total)}",
        ))
        db.session.commit()
        flash(f"Transaksi #{transaksi.id} berhasil!", "success")
        return redirect(url_for("kasir"))

    return render_template("kasir.html", produks=produks)


@app.route("/stok", methods=["GET", "POST"])
@login_required
def stok():
    is_owner = session.get("role") == "owner"
    if request.method == "POST":
        if not is_owner and not verify_owner_pin(request.form.get("pin_owner")):
            flash("PIN Owner salah!", "danger")
            return redirect(url_for("stok"))

        action = request.form.get("action")
        if action == "tambah_produk":
            p = Produk(
                nama=request.form["nama"].strip(),
                kategori=request.form.get("kategori", "").strip(),
                satuan=request.form["satuan"],
                harga_modal=float(request.form["harga_modal"]),
                harga_jual=float(request.form["harga_jual"]),
                stok=float(request.form["stok"]),
                stok_minimum=float(request.form.get("stok_minimum", 5)),
            )
            db.session.add(p)
            db.session.commit()
            flash("Produk berhasil ditambahkan!", "success")
        elif action == "tambah_stok":
            p = db.session.get(Produk, int(request.form["produk_id"]))
            if not p:
                flash("Produk tidak ditemukan.", "danger")
                return redirect(url_for("stok"))
            jumlah = float(request.form["jumlah"])
            p.stok += jumlah
            db.session.add(StokMasuk(
                produk_id=p.id,
                supplier_id=int(request.form["supplier_id"]),
                jumlah=jumlah,
            ))
            db.session.commit()
            flash("Stok masuk berhasil dicatat!", "success")

    return render_template(
        "stok.html",
        produks=Produk.query.order_by(Produk.nama).all(),
        suppliers=Supplier.query.order_by(Supplier.nama).all(),
        stok_masuk_riwayat=StokMasuk.query.order_by(StokMasuk.tanggal.desc()).limit(50).all(),
        is_owner=is_owner,
    )


@app.route("/supplier", methods=["GET", "POST"])
@owner_required
def supplier():
    if request.method == "POST":
        db.session.add(Supplier(
            nama=request.form["nama"].strip(),
            kontak=request.form.get("kontak", "").strip(),
        ))
        db.session.commit()
        flash("Supplier berhasil ditambahkan!", "success")
    return render_template("supplier.html", suppliers=Supplier.query.order_by(Supplier.nama).all())


@app.route("/hutang", methods=["GET", "POST"])
@login_required
def hutang():
    if request.method == "POST":
        h = db.session.get(Hutang, int(request.form["hutang_id"]))
        jumlah = float(request.form["jumlah_bayar"])
        if not h or h.status == "Lunas":
            flash("Data hutang tidak valid.", "danger")
            return redirect(url_for("hutang"))
        if jumlah <= 0 or jumlah > h.sisa_hutang:
            flash("Jumlah cicilan tidak valid.", "danger")
            return redirect(url_for("hutang"))
        h.sisa_hutang -= jumlah
        if abs(h.sisa_hutang) < 0.000001:
            h.sisa_hutang = 0
            h.status = "Lunas"
        db.session.add(CicilanHutang(hutang_id=h.id, jumlah_bayar=jumlah))
        db.session.commit()
        flash("Cicilan berhasil dicatat!", "success")
    return render_template("hutang.html", hutangs=Hutang.query.order_by(Hutang.tanggal.desc()).all())


@app.route("/pengeluaran", methods=["POST"])
@owner_required
def pengeluaran():
    db.session.add(Pengeluaran(
        keterangan=request.form["keterangan"].strip(),
        jumlah=float(request.form["jumlah"]),
    ))
    db.session.commit()
    flash("Pengeluaran berhasil dicatat.", "success")
    return redirect(url_for("laporan"))


@app.route("/laporan")
@owner_required
def laporan():
    transaksis = Transaksi.query.filter_by(status="Selesai").order_by(Transaksi.tanggal.desc()).all()
    omzet = sum(t.total_belanja for t in transaksis)
    laba_kotor = sum(
        (d.harga_satuan - d.produk.harga_modal) * d.jumlah
        for t in transaksis for d in t.detail
    )
    pengeluarans = Pengeluaran.query.order_by(Pengeluaran.tanggal.desc()).all()
    total_pengeluaran = sum(p.jumlah for p in pengeluarans)
    return render_template(
        "laporan.html",
        omzet=omzet,
        laba_kotor=laba_kotor,
        total_pengeluaran=total_pengeluaran,
        laba_bersih=laba_kotor - total_pengeluaran,
        transaksis=transaksis,
        pengeluarans=pengeluarans,
        riwayat_aktivitas=RiwayatAktivitas.query.order_by(RiwayatAktivitas.tanggal.desc()).limit(100).all(),
    )


@app.route("/batal_transaksi/<int:id>", methods=["POST"])
@login_required
def batal_transaksi(id):
    if session.get("role") != "owner" and not verify_owner_pin(request.form.get("pin_owner")):
        flash("PIN Owner salah! Pembatalan ditolak.", "danger")
        return redirect(url_for("laporan"))
    t = db.session.get(Transaksi, id)
    if t and t.status == "Selesai":
        t.status = "Dibatalkan"
        for d in t.detail:
            p = db.session.get(Produk, d.produk_id)
            if p:
                p.stok += d.jumlah
        db.session.add(RiwayatAktivitas(
            user=session["user"],
            aktivitas=f"Membatalkan transaksi #{t.id} senilai {rupiah(t.total_belanja)}",
        ))
        db.session.commit()
        flash(f"Transaksi #{t.id} dibatalkan dan stok dikembalikan.", "info")
    return redirect(url_for("laporan"))


def init_db():
    with app.app_context():
        db.create_all()
        if not User.query.first():
            db.session.add_all([
                User(username="owner", role="owner", pin_hash=generate_password_hash("1234")),
                User(username="kasir", role="kasir", pin_hash=generate_password_hash("1111")),
            ])
            db.session.commit()


init_db()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
