# Toko Sembako — versi mobile/APK

Project ini menggabungkan backend Flask + SQLite dengan seluruh halaman kasir dan wrapper Android berbasis Kivy/WebView.

## Login default
- Owner: `owner` / PIN `1234`
- Kasir: `kasir` / PIN `1111`

Segera ganti PIN dan `SECRET_KEY` sebelum dipakai sungguhan.

## Jalankan sebagai web app
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements-web.txt
python app.py
```

Buka http://127.0.0.1:5000

## Build APK
Build APK memakai Buildozer dan umumnya dilakukan di Linux/WSL karena Android SDK/NDK diperlukan.

```bash
pip install buildozer
buildozer android debug
```

APK debug akan muncul di folder `bin/`.

Catatan: pada build pertama, Buildozer akan mengunduh komponen Android SDK/NDK sehingga proses bisa cukup lama.
