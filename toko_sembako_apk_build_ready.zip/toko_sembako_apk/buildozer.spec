[app]
title = Toko Sembako
package.name = tokosembako
package.domain = org.tokosembako
source.dir = .
source.include_exts = py,html,css,js,db,png,jpg,jpeg
version = 1.0.0
requirements = python3,kivy==2.3.1,flask==3.1.2,flask-sqlalchemy==3.1.1,werkzeug==3.1.3
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 24
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
